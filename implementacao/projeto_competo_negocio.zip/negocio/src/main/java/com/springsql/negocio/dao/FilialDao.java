package com.springsql.negocio.dao;

import com.springsql.negocio.model.Filial;
import org.springframework.data.repository.CrudRepository;

public interface FilialDao extends CrudRepository<Filial,Integer>{
}
