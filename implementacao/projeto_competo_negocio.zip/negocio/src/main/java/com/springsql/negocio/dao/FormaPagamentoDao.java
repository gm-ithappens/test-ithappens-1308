package com.springsql.negocio.dao;

import com.springsql.negocio.model.FormaPagamento;
import org.springframework.data.repository.CrudRepository;

public interface FormaPagamentoDao extends CrudRepository<FormaPagamento,Integer>{
}
