package com.springsql.negocio.dao;

import com.springsql.negocio.model.ItensPedido;
import org.springframework.data.repository.CrudRepository;

public interface ItensPedidoDao extends CrudRepository<ItensPedido,Integer>{
}
